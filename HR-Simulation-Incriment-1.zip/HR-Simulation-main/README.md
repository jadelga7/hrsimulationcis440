# HR-Simulation
If you die in the game you die in real life.
